



#include "libtool.h"
#include "dl_ext.h"




int main(int argi, char* argv[])
{

out_p = &printf;

void *p;
char **buff;
char *cwd;
mod_* c;

symbol cs[5];
init(c,mod_);
init(cwd,64);

load_mod(c,"/system/lib/libc.so");nl_
cs[0].addr = sym_mod(c,"getcwd");nl_
cs[1].addr = sym_mod(c,"execv");nl_
cs[2].addr = sym_mod(c,"system");nl_

out_("loading...");nl_

castf(cs[2].addr)("clear");

nl_
out_("\n\n\nSPAWNER FLAIL M_O"); nl_
out_("------------------------");nl_
out_("exec,posix spawner batch flail");nl_
p = 
castf(cs[0].addr)(cwd,64);
out_("%s",p);nl_


if(argi>1){
buff = & argv [1];

sprintf(cwd,"%s/%s",p,*buff);
nl_
out_("SPAWNER MESSAGE:\n %s |", cwd);nl_
castf(cs[1].addr)(cwd,(char*) buff); //execv



		}
return 0;
}


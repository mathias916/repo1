
#include "libtool.h"





int main(int argi, char *cstr[])
{

void * func_m;
void * handle;
void *slink;
void *printf_;
MOD * dll;
struct module *c;


c = malloc(sizeof(struct module));

dll = init_dlmod();


c->mod   =
dll->loadso_("/system/lib/libc.so");
c->addr =
dll->loadso_sym(c->mod, "wait");
handle = c->addr;



if(!so_error(c) ) printf("\nwait ok");
else return 1;


dll->loadso_sym(c->mod  ,"symlink");
slink = c->addr;
dll->loadso_sym(c->mod,"printf");
printf_ = c->addr;


if(slink == NULL &&  printf_ == NULL)
{
   printf("\nso libs fail");
	return 1;
}


if(argi > 1) 
{

    castf( slink )
      (cstr[1], cstr[2]);

   castf( printf_) ("\nsymlink: %s \ncreated for %s",
		    cstr[2], cstr[1] );

   return 0;
}

if(argi <= 1) 
{

castf(printf_)("\nmissing: <old path> : <link name>");
	
}


if (c!=NULL) { so_close(c); so_close(dll); } 
   
return 0;


}

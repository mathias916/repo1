
#include <stdio.h>
#include <arpa/inet.h>>
#include <sys/socket.h>


/*
#include <windows.h>
#include <winsock.h>
*/

typedef int SOCKET;


//sin_family, sin_port, struct in_addr sin_addr,sin_zero[8]
//u_short sa_family, sa_data[14]  up to 14 bytes of direct address

typedef struct soc_ftype
{
int af,type,proto;
struct sockaddr_in sin_addr;
struct sockaddr soc_addr;		
short error;			
SOCKET conn; 			//connection
struct in_addr * addr_net;
char *address_str;
char *addr_ip;
void *data_t;

void * (*ss_addr_net)(void*,...);	//set [in: ip_path_net_addr_cstr *] [out:union* addr_in]
void * (*gcs_s_addr_net)(void*,...);    //get [in: (union) struct add_in  ] [out: net_cstr]
void * (*getconninfo)(void*,...);
void * (*Connect)(void *,...);
void * (*close)(void*,...);
void * (*msg_method)(void*,...);

////////////////////////////////////////////
//interface function fields (:callback) //
//				       //
void * interface_handle;
void * interface_hook;
void * unknown;
/////////////////////////////////// //
}soc_ftype;


#define msg_method__ printf
#define msg__	((void* (*)(void*,...)) (msg_method__))

///////////////////////////////////////////////
//prototypes

void * scopyip(char *out,char sa_data[14] );


/////////////////////////////////////////////////////////////
typedef unsigned short unlv;


//////////////////////////////////////////////////////////////
//SOCK_DGRAM
//SOCKET PASCAL FAR socket (int af, int type, int protocol);
/*
union S_un
unsigned long PASCAL FAR inet_addr (const char FAR * cp);
char FAR * PASCAL FAR    inet_ntoa (struct in_addr in);
*/


void * set_net_addr(char * path)
{
struct in_addr  out_addr; 
unsigned long i;
i = inet_addr(path);
  
memcpy 
(&out_addr ,&i, sizeof(struct in_addr) ) ;

return &out_addr;
}

void * get_net_addr(void * addr_union_)
{
char out_addr[256];
struct in_addr tmp_addr;

memcpy(
&tmp_addr,  addr_union_, sizeof(struct in_addr) );




memset(out_addr,0,256);
sprintf(out_addr,"%s",
	inet_ntoa(tmp_addr));

//printf("\ninet_a:f:%d", out_addr );
//if(out_addr != NULL && out_addr)

return out_addr;
}


void * SockClose(void *soc_ftype_)
{

int rtn;


if( rtn = (
abs(shutdown(((soc_ftype*)soc_ftype_)->conn , SHUT_RD)) ||
abs(shutdown(((soc_ftype*)soc_ftype_)->conn , SHUT_WR)) ||
abs(shutdown(((soc_ftype*)soc_ftype_)->conn , SHUT_RDWR))
)
){ msg__("\nconnection closed :%d",rtn); }
else
rtn = close(((soc_ftype*)soc_ftype_)->conn );

return rtn;
}

void * SockConnect(void *soc_ftype_, char* path_net)
{
int rtn = 0;

soc_ftype * sox_out;
if(soc_ftype_ == NULL) soc_ftype_ = sox_out;
else
{
sox_out = malloc(sizeof(soc_ftype));
*sox_out = *((soc_ftype*)soc_ftype_);
}

#define con ((soc_ftype*)sox_out)

if(path_net != NULL){
con->addr_net = malloc(sizeof(struct in_addr));

msg__("\ninput:%s",path_net);

printf("\nnet_addr:f:%s",
 con->addr_net = (struct in_addr*) set_net_addr(path_net) 
);

printf("\nnet_path:f:%s", 
con->address_str = get_net_addr(con->addr_net) 
);

}
////////////////do scan mode
//.
///scan



	//create 
	con->conn = socket(con->af,con->type,con->proto);
	
	
		msg__("\nsocket open:%d",con->conn);
	  	msg__("\nbuilding address");

rtn = 	

bind(	con->conn	,		//socket
		 	&con->soc_addr   ,		/*struct sockaddr *addr*/ 
			sizeof(con->soc_addr) 
			);

	msg__("\nbinding:%s",rtn == 0 ? "SUCCES" : "FAIL" );

rtn =
        
         connect(con->conn,    		//socket
				&con->soc_addr,  		//const struct sockaddr FAR *name
				sizeof(con->soc_addr) 	/*int namelen*/
				);

	msg__("\nconnection:%s",rtn == 0 ? "SUCCES" : "FAIL" );
		
			return rtn;
		

#undef con
return NULL;
}

void *
SockSend(void * sock_t, void * str_sent)
{
int bytes_sent = 
send (, const char FAR * buf, int len, int flags);



}


void * scopyip(char *out,char sa_data[14] )
{
if(sa_data)
{
	out = malloc(18);
	out = &sa_data[0];
		
return out;
}
else 
return NULL;
}


int main(int argi, char * argv[]) //stub test
{		  //class ,type, protocol 

void * arg_cmd;
soc_ftype com_ = { AF_INET ,SOCK_DGRAM ,IPPROTO_UDP};

if(argi >1)
{
 arg_cmd = argv[1];

printf("\nSocket:responded:%s", 
	SockConnect(&com_, (char*) arg_cmd)  == 0 ? 
	"SOCKET, PORT CONNECTED" :
	"SOCKET CONNECTION FAILED"); 
} else {

	printf("\nSocket:responded:%s",                                    SockConnect(&com_, "74.6.143.25") == 0 ?
        "SOCKET, PORT CONNECTED" :
        "SOCKET CONNECTION FAILED");
}


SockClose(&com_);

getc(stdin);

return 0;
}



#ifdef NOTES_ONLY_

//protocols
/*
#define IPPROTO_IP              0               /* dummy for IP */
#define IPPROTO_ICMP            1               /* control message protocol */
#define IPPROTO_IGMP            2               /* group management protocol */
#define IPPROTO_GGP             3               /* gateway^2 (deprecated) */
#define IPPROTO_TCP             6               /* tcp */
#define IPPROTO_PUP             12              /* pup */
#define IPPROTO_UDP             17              /* user datagram protocol */
#define IPPROTO_IDP             22              /* xns idp */
#define IPPROTO_ND              77              /* UNOFFICIAL net disk proto */
#define IPPROTO_RAW             255             /* raw IP packet */
#define IPPROTO_MAX             256
 * UNIX TCP sockets
#define IPPORT_EXECSERVER       512
#define IPPORT_LOGINSERVER      513
#define IPPORT_CMDSERVER        514
#define IPPORT_EFSSERVER        520
 * UNIX UDP sockets
#define IPPORT_BIFFUDP          512
#define IPPORT_WHOSERVER        513
#define IPPORT_ROUTESERVER      520
                                        520+1 also used  {"games ports apps coms" 'Devicelink','gamespy'}
 * Ports < IPPORT_RESERVED are reserved for
 * privileged processes (e.g. root).
 */
#define IPPORT_RESERVED         1024
 * Address families.
#define AF_UNSPEC       0               /* unspecified */
#define AF_UNIX         1               /* local to host (pipes, portals) */
#define AF_INET         2               /* internetwork: UDP, TCP, etc. */
#define AF_IMPLINK      3               /* arpanet imp addresses */
#define AF_PUP          4               /* pup protocols: e.g. BSP */
#define AF_CHAOS        5               /* mit CHAOS protocols */
#define AF_IPX          6               /* IPX and SPX */
#define AF_NS           6               /* XEROX NS protocols */
#define AF_ISO          7               /* ISO protocols */
#define AF_OSI          AF_ISO          /* OSI is ISO */
#define AF_ECMA         8               /* european computer manufacturers */
#define AF_DATAKIT      9               /* datakit protocols */
#define AF_CCITT        10              /* CCITT protocols, X.25 etc */
#define AF_SNA          11              /* IBM SNA */
#define AF_DECnet       12              /* DECnet */
#define AF_DLI          13              /* Direct data link interface */
#define AF_LAT          14              /* LAT */
#define AF_HYLINK       15              /* NSC Hyperchannel */
#define AF_APPLETALK    16              /* AppleTalk */
#define AF_NETBIOS      17              /* NetBios-style addresses */
#define AF_VOICEVIEW    18              /* VoiceView */
#define AF_FIREFOX      19              /* FireFox */
???LINES MISSING
#define s_lh    S_un.S_un_b.s_b3

struct sockaddr_in {
        short   sin_family;
        u_short sin_port;
        struct  in_addr sin_addr;
        char    sin_zero[8];

struct sockaddr {
        u_short sa_family;               address family 
        char    sa_data[14];             up to 14 bytes of direct address 
};


struct sockproto {
        u_short sp_family;               address family 
        u_short sp_protocol;             protoc
};
*/

/*
sockaddr
        u_short sa_family;              /// address family 
        char    sa_data[14];            /// up to 14 bytes of direct address 
(i.e. ip address 14 bytes wide )
255 . 255 . 255 . 255
*/

#endif

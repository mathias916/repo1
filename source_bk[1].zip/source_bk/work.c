From: Maria Johnson
(Acara Solutions)

Hi, I called you in regards to Materials Handler role with Siemens Corporation in Sacramento, CA. Give me a call / text me at 425-381-4844 to discuss about it. Pay $18.70/hr.

Reply STOP to opt out.

:sa
attnd:
Maria Johnson - with Siemens Corp. 
Materials Handler role.

-assembler 17 seventeen/hr
-wiring electrical 18.~eighteen /hour


Yes I am interested in the role for position of 
Materials Handler for Siemens Corp.

mathias james odea
mjo - indi. private contractor
o.s.h.a. FORKLIFT OPERATOR/DRIVER CERT.
mathias.james2021@gmail.com
mobile phone : 916 589 7803

-----
called for interview aug 24 twenty four











#include "list_.h"


int main( int arg, char *argv[])
{

FILE * in;

#define void unsigned int

if( arg > 1)
{
 in = fopen(argv[1], "r");
 void * key = malloc(80);
 void * buff = malloc(80*40);
 void * ln = malloc(12);
  

 if(ferror(in) == 0)
  { 
    int l =-1;
    while( ferror(in) == 0 && l < 80*40 ){
    (ln[0]) = fgetc(in);
    if(ln[0] > 10 && ln[0] < 124)(buff[++l])= ln[0];
    if(l >= 80*40 -1) 
     printf("%c", buff[l]);
      
    }//while
    
   }//if err





}//if argi


return 0;
}

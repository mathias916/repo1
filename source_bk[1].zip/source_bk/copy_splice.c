





//splice must be 1 pipe arg param at least

copy_file;




int main()
{




}

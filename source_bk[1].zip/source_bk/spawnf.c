



#include "list_.h"

typedef struct module MOD; 
typedef struct list_ LST;
typedef struct node_ NODE;

int main (int argi, char* argvm[])
{

FILE *share;
FILE *outf;
 

 void * itor,*tmp;
 MOD * i;
 LST * l = list();
 NODE * data_i ;


//
 //data_i = new_data( sizeof(MOD));
 /*
 data_i->addr = malloc(sizeof(int));
 data_i->data = malloc (sizeof(MOD));
 data_i->key =  malloc (64);
 data_i->parent = data_i;
*/
int  size_d[]  = {sizeof(MOD)};
data_i = new_data(size_d);

 i = so_open("/system/lib/libc.so", "dup");
 
  

   *((MOD*)data_i->data) = *i;
      l->itor_ = data_i;
      l->head_ = l->itor_;
      l->itor_ = l->itor_->next;
        
 
/*
   l->itor_ = new_data(size_d);
    l->itor_ = new_link(data_i);
     l->itor_->parent = data_i;
      l->child  = l->itor_;
       */
       

      
     



if(i &&  i->info(i)) 
	share = ((FILE*) data_get(i, fvarg)(stdout));


i = so_sym("system");
if(i &&  i->info(i)) 
data_get(i,fvarg)("echo sys loaded");




	/*
{
data_get(i,fvarg) ("echo systems");

#define sz(z) (sizeof (z))


data_i = new_data( sz(MOD));


 if( l->child == NULL) {
	 data_i->parent = l->itor;
	 l->child = data_i;
	 l->itor = data_i;
 }
          
 * ((MOD*) ((node_*)l->itor)->data)   = *i;
   itor = l->itor;
   
   tmp = new_link(itor);

}

  i = so_sym("dup");
  
    ((node_*)tmp)->data  = set_data(i, sz(MOD));
     
   data_get(  (MOD*) ((node_*)itor)->data, fvarg)
     ("echo systems loaded");

 // i = so_open ( "fork");
*/


return 0;
}
